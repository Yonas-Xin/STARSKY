from skystar.sky_dataset.create_dataset import data_to_npz
from skystar.sky_dataset.load import load
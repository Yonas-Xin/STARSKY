from skystar.core import Variable
from skystar.core import Function
from skystar.core import as_scalar
from skystar.core import as_variable
from skystar.core import config_using
from skystar.core import setup_variable
from skystar.core import no_grad
from skystar.core import TrainingMode,Set_TrainingMode,Get_TrainingMode
from skystar.dataloader import Dataloader
from skystar import utils
from skystar import cuda
setup_variable()